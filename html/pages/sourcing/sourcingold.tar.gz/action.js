$(document).ready(function () {
    getFullname();
    getCandidates();
    $('#candidateSelection').live('change', function(){
        $('#activityList').text('');
        var obj=new Object();
        obj._id=$('#candidateSelection').val();
        if(obj._id!=='default')
            Backing.getActivities(obj);
        if(obj._id==='default'){
            //$("#JTDropDown").html("<option value='default'>Job Title</option>");
            //$('#select5').text("Job Title");
        }
    });
});
function getFullname(){
    Backing.getFullname();
}
function getCandidates(){
    Backing.getCandidates();
}