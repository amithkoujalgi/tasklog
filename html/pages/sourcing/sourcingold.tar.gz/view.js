var MyEventEmitter = function(){};
MyEventEmitter.prototype = new AbstractEventsDispatcher;
var emitter = new MyEventEmitter();

emitter.on('companiesLoaded',function(data){
	
	var html="<option value='Select Company'>Select Company</option>"
	for(var i in data){
		html +="<option value="+data[i]+">"+data[i]+"</option>"
	}
	$("#companySelection").html(html)

})

emitter.on('jobTitlesLoaded',function(data){

	var html="<option value='Select JD'>Select JD</option>"
	for(var i in data){
		html +="<option value="+data[i]._id+">"+data[i].jobTitle+"</option>"
	}
	$("#jdSelection").html(html)

})

emitter.on("JDLoaded",function(){
	if(backingObject.currJDID =="")
		$("#JDPlacehoalder").text("Please Select Company and JD")
	else{
		$("#JDPlacehoalder").text(backingObject.JD)
		$('.searchlink').show()
		$('.searchcontent').show()
		emitter.emit($('input[name=searchMethod]:checked').val()+"Form")
		
	}
		
})

emitter.on("RegularForm",function(){

	var html = "<tr><td class='searchFormFirstTd'><b class='orangetext'>Keywords </b></td><td></td><td></td></tr>"
	html += "<tr><td class='searchFormFirstTd'><span class='orangetext'>Any of </span></td><td class='searchFormSecondTd'>:</td><td class='searchFormTrdTd'><input type='text' value='' class='input-txt form-inputtext form-inputtext-big input-box input-box1' id='anyKeywords'></td></tr>"
	html += "<tr><td class='searchFormFirstTd'><span class='orangetext'>All of </span></td><td class='searchFormSecondTd'>:</td><td class='searchFormTrdTd'><input type='text' value='' class='input-txt form-inputtext form-inputtext-big input-box input-box1' id='allKeywords'></td></tr>"
	html += "<tr><td class='searchFormFirstTd'><span class='orangetext'>Excluding </span></td><td class='searchFormSecondTd'>:</td><td class='searchFormTrdTd'><input type='text' value='' class='input-txt form-inputtext form-inputtext-big input-box input-box1' id='excludingKeywords'></td></tr>"
	html += "<tr><td class='searchFormFirstTd'><b class='orangetext'>Form Fields </b></td><td></td><td></td></tr>"
	html += "<tr><td class='searchFormFirstTd'><span class='orangetext'>Field </span></td><td class='searchFormSecondTd'>:</td><td class='searchFormTrdTd'><input type='text' value='' class='input-txt form-inputtext form-inputtext-big input-box input-box1' id='searchInputs'></td></tr>"

	$('#searchForm').html(html)	
	
})
emitter.on("BooleanForm",function(){
	var html="<br/><b class='orangetext'>Boolean Text :</b><br/>"
	html +="<textarea class='txtarea' ></textarea>"
	html +="<br/><b class='orangetext'>Form Fields :</b><br/>"
	html +="<input type='text' value='' style='margin-left:2.5%;' class='input-txt form-inputtext form-inputtext-big input-box input-box1' id='searchInputs'>"

	$('#searchForm').html(html)	
	
})
emitter.on('formFields',function(data){
	
	var html = "<tr><td class='searchFormFirstTd'><span class='orangetext'>Field</span></td><td class='searchFormSecondTd'>:</td><td class='searchFormTrdTd'><div class='formCriteriesTextDiv' style='border: 1px solid #D4D4D4;border-radius: 3px 3px 3px 3px;background-color:#F8F8FF;margin-left:0.5%;margin-right:1.5%;'><span style='margin-left:1%;' class="+data.split('=')[0].trim().replace(/\s+/g,'_')+">"+data+"</span><span style='float:right;margin-right:1%;'><a class='deleteInput' style='cursor:pointer;color:#5A5B5B;'>X<a></span></div></td></tr>"
	$('#searchForm').append(html)	
})
emitter.on('searchResults',function(data){
	if(data.length > 0){
		$('#resultDiv').empty();
		for(var i in data){
		
			emitter.emit(data[i].boardSource+'Snippet',data[i]);
		}
	}else{
		$('#resultDiv').empty();
	}
	if(backingObject.resultTabCandidateFocus ){
		$('.addToCandidateButton').attr('class','source-link getResumeButton');
	}
	
})
emitter.on('searchHistoryLoaded',function(){
	var data=""
	if(backingObject.currHilightedTab === "similarSearchTab")
		data = 	backingObject.similarSearchQueries;
	else
		data = 	backingObject.searchHistory;
	var html = ""
	for(var i in data){
		
		html += "<tr>";
		html += "<td width='10%'><span>"+getUTCString(data[i].lastRunOn)+"</span></td>"
		html += "<td width='65%'>"+data[i].searchName+"</td>"
		html += "<td width='10%'><span class='font-color1'>"+data[i].name+"</span></td>"
	//	html += "<td width='15%'><a href='javascript:void(0)' class='nsearch' id="+data[i]._id+"></a><a href='javascript:void(0)' class='search-view'></a> </td>"
		html += "<td width='15%'><a href='javascript:void(0)' class='nsearch' id="+data[i]._id+"></a></td>"
		html += "</tr>";
	}
	$("#showSearchHistory").html(html)
	
})

emitter.on("rearrangePortals",function(){
	var domesticPortals = ["Monster_India","Naukri","Timesjob","Career_Builder_India"];
	var foreignPortals = ["Career_Builder_US"," Monster_US","Dice"]
	var general = ["Zoominfo","Linkedin","hiresys","others"]
    var html=""
	if(backingObject.geography === "foreign"){
		for(var i in foreignPortals)
			if(foreignPortals[i] === "Career_Builder_US")
				html +="<li><a href='javascript:void(0);' class="+foreignPortals[i]+">CB</a></li>"
			else
				html +="<li><a href='javascript:void(0);' class="+foreignPortals[i]+"></a></li>"
	}else{
		for(var i in domesticPortals)
			if(foreignPortals[i] === "Career_Builder_India")
				html +="<li><a href='javascript:void(0);' class="+domesticPortals[i]+">CB</a></li>"
			else
			    	html +="<li><a href='javascript:void(0);' class="+domesticPortals[i]+"></a></li>"
	}
	for(var i in general)
		html +="<li><a href='javascript:void(0);' class="+general[i]+"></a></li>"

	$('#jobPortalsSourceIcons').html(html)
})